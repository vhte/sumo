#!/usr/bin/env python
from __future__ import division
import os, sys
import optparse
import subprocess
import random
from xml.dom import minidom


xmldoc = minidom.parse('tripinfo.xml')
itemlist = xmldoc.getElementsByTagName('tripinfo')
print "Total de carros: %i" % (len(itemlist))
#print itemlist[0].attributes['arrival'].value
print "Tempo de chegada do ultimo carro: %s" % (itemlist[len(itemlist)-1].attributes['arrival'].value)

# Calculo do total de carros que atravessaram NS, SN, LO, OL
NS = 0
SN = 0
LO = 0
OL = 0
for s in itemlist:
	# python nao tem switch case :(
	if "NS" in s.attributes['id'].value:
		NS += 1
	elif "SN" in s.attributes['id'].value:
		SN += 1
	elif "LO" in s.attributes['id'].value:
		LO += 1
	elif "OL" in s.attributes['id'].value:
		OL += 1

print "TOTAL DE CARROS\nNorte/Sul: %i\nSul/Norte: %i\nLeste/Oeste: %i\nOeste/Leste: %i" % (NS,SN,LO,OL)

# Podemos melhorar isto aqui e verificar os carros que passaram nos horarios de pico, etc...
# Usar o duration e waitSteps

tempos = []
for s in itemlist:
	tempos.append(float(s.getAttribute('duration')))
	#print s.getAttribute('duration')
f = open('teste.xml', 'w')

#print >> f, "x = ["
#print >> f,', '.join(tempos)
#print >> f, " ];"

media = sum(tempos)/len(tempos)
print "Media: %s" % (media)